import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// ignore: depend_on_referenced_packages
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const SnakeApp());
}

class SnakeApp extends StatelessWidget {
  const SnakeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SnakeGame(),
    );
  }
}

class SnakeGame extends StatefulWidget {
  const SnakeGame({super.key});

  @override
  State<SnakeGame> createState() => _SnakeGameState();
}

enum Direction { up, down, left, right }

class _SnakeGameState extends State<SnakeGame> {
  static const int rowSize = 20;
  static const int totalSquares = rowSize * rowSize;

  List<int> snake = [45, 65, 85];
  int food = 200;

  Direction direction = Direction.right;
  bool isPlaying = false;

  int score = 0;
  int bestScore = 0;

  int speed = 300;
  Timer? gameTimer;

  final player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    loadBestScore();
  }

  // 💾 rekord betöltés
  void loadBestScore() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      bestScore = prefs.getInt("bestScore") ?? 0;
    });
  }

  // 💾 rekord mentés
void saveBestScore() async {
  final prefs = await SharedPreferences.getInstance();

  if (score > bestScore) {
    bestScore = score; // 🔥 EZ HIÁNYZOTT
    await prefs.setInt("bestScore", bestScore);
  }
}
  void startGame() {
    score = 0;
    speed = 300;
    isPlaying = true;

    gameTimer?.cancel();
    gameLoop();
  }

  void gameLoop() {
    gameTimer = Timer.periodic(Duration(milliseconds: speed), (timer) {
      if (!isPlaying) {
        timer.cancel();
      }
      moveSnake();
    });
  }

  void moveSnake() async {
    setState(() {
      int newHead;

      switch (direction) {
        case Direction.down:
          newHead = snake.last + rowSize;
          break;
        case Direction.up:
          newHead = snake.last - rowSize;
          break;
        case Direction.left:
          newHead = snake.last - 1;
          break;
        case Direction.right:
          newHead = snake.last + 1;
          break;
      }

      // 💀 ütközés
      if (newHead < 0 ||
          newHead >= totalSquares ||
          (direction == Direction.left && newHead % rowSize == rowSize - 1) ||
          (direction == Direction.right && newHead % rowSize == 0) ||
          snake.contains(newHead)) {
        isPlaying = false;
        saveBestScore();
        playGameOverSound();
        showGameOver();
        return;
      }

      snake.add(newHead);

      // 🍎 evés
      if (newHead == food) {
        score++;
        food = Random().nextInt(totalSquares);

        playEatSound();

        if (speed > 80) speed -= 10;

        gameTimer?.cancel();
        gameLoop();
      } else {
        snake.removeAt(0);
      }
    });
  }

  // 🎵 hangok
 void playEatSound() async {
  await player.play(AssetSource('assets/eat'));
}

void playGameOverSound() async {
  await player.play(AssetSource('assets/gameover'));
}

  void showGameOver() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: const Text("GAME OVER"),
          content: Text("Pont: $score\nRekord: $bestScore"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                resetGame();
              },
              child: const Text("ÚJRA"),
            )
          ],
        );
      },
    );
  }

  void resetGame() {
    setState(() {
      snake = [45, 65, 85];
      direction = Direction.right;
      food = Random().nextInt(totalSquares);
      isPlaying = false;
      score = 0;
      speed = 300;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,

      body: Column(
        children: [
          // SCORE + BEST
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Text("Pontszám: $score",
                    style: const TextStyle(color: Colors.white, fontSize: 22)),
                Text("Rekord: $bestScore",
                    style: const TextStyle(color: Colors.grey, fontSize: 18)),
              ],
            ),
          ),

          Expanded(
            child: RawKeyboardListener(
              focusNode: FocusNode()..requestFocus(),
              onKey: (event) {
                if (event is RawKeyDownEvent) {
                  if (event.logicalKey == LogicalKeyboardKey.arrowUp &&
                      direction != Direction.down) {
                    direction = Direction.up;
                  } else if (event.logicalKey ==
                          LogicalKeyboardKey.arrowDown &&
                      direction != Direction.up) {
                    direction = Direction.down;
                  } else if (event.logicalKey ==
                          LogicalKeyboardKey.arrowLeft &&
                      direction != Direction.right) {
                    direction = Direction.left;
                  } else if (event.logicalKey ==
                          LogicalKeyboardKey.arrowRight &&
                      direction != Direction.left) {
                    direction = Direction.right;
                  }
                }
              },
              child: GridView.builder(
                itemCount: totalSquares,
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: rowSize,
                ),
                itemBuilder: (context, index) {
                  if (index == snake.last) {
                    return Container(
                      margin: const EdgeInsets.all(1),
                      decoration: BoxDecoration(
                        color: Colors.lightGreenAccent,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    );
                  } else if (snake.contains(index)) {
                    return Container(
                      margin: const EdgeInsets.all(1),
                      color: Colors.green,
                    );
                  } else if (index == food) {
                    return Container(
                      margin: const EdgeInsets.all(1),
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                    );
                  } else {
                    return Container(
                      margin: const EdgeInsets.all(1),
                      color: Colors.grey[900],
                    );
                  }
                },
              ),
            ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton.extended(
        onPressed: startGame,
        label: const Text("START"),
        icon: const Icon(Icons.play_arrow),
      ),
    );
  }
}